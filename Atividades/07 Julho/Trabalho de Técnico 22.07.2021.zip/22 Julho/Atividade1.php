<?php

$nome = 'Humberto';
echo $nome.'<br>';

//FOR- contador interno - quantidade de vezes que deve executar

for ($i=1; $i <= 50 ; $i++) { 
    echo $i.')'.$nome.'<br>';
}
echo "Banana";

?>