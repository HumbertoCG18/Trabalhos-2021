<?php

$x = -5;
while ($x <= 5) {
    echo $x.'<br>';
    $x++;
}

echo 'amendoim';

?>