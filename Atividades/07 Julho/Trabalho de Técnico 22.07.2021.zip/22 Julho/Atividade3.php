<?php

$nomes = array(1=>'Humberto',2=>'Guilherme',3=>'Arthur Dondoni',4=>'Thiago',5=>'Aléxis'); 
for ($i=1; $i <=5; $i++) { 

}

$x = 1;
while ($x <= 5) {
    echo $x.'-'.$nomes[$x].'<br>';
    $x++;
}


?>