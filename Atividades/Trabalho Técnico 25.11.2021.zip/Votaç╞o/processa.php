<?php

include('conecta.php');

$id=0;
$um=1;
$radio=$_POST['radio'];

if($radio == 'BL'){ $sql=$mysqli->prepare('update ENQUETE set q1=q1+? where id=?'); }
if($radio == 'MA'){ $sql=$mysqli->prepare('update ENQUETE set q2=q2+? where id=?'); }
if($radio == 'IP'){ $sql=$mysqli->prepare('update ENQUETE set q3=q3+? where id=?'); }
if($radio == 'MT'){ $sql=$mysqli->prepare('update ENQUETE set q4=q4+? where id=?'); }

$sql->bind_param("ii",$um,$um);
$sql->execute();

$sql=$mysqli->prepare('select * from ENQUETE');
$sql->execute();
$sql->bind_result($idfinal,$q1,$q2,$q3,$q4);
$sql->fetch();

$total=$q1+$q2+$q3+$q4;
$BL=($q1*100)/$total. '%';
$MA=($q2*100)/$total. '%';
$IP=($q3*100)/$total. '%';
$MT=($q4*100)/$total. '%';

echo "
    Resultado:
    <br>
    <br>
    Bruce Lee: $BL <br>
    Muhammad Ali: $MA <br>
    Yip Man: $IP <br>
    Mike Tyson: $MT <br>
";


?>