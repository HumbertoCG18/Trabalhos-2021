<?php
$servidor="localhost";
$usuario="root";
$senha="";
$bancodedados="db_mysqli";
$mysqli=new mysqli($servidor,$usuario,$senha,$bancodedados);

?>