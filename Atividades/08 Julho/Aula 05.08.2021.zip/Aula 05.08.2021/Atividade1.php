<?php

for ($contador=1; $contador <16 ; $contador++) { 
    echo $contador.'<br>';
}

?>