<?php

echo '<ul>';
for ($contador=1; $contador <=10 ; $contador++) {

    echo '<li>'.$contador.'</li>';

}
echo '</ul>';

?>