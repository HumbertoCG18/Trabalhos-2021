<?php

$x = 1;
while ($x <= 15) {
    echo $x.'<br>';
    $x++;
}

echo 'Humberto';

?>