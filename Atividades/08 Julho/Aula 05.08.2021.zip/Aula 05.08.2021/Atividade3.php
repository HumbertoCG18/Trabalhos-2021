<?php

$x = 0;
while ($x <= 14) {
    echo '<br>';
    $x++;

    if($x % 2 == 1)
    echo "$x É Ímpar";

    else
    echo "$x É Par";
}
echo '<br>';
echo 'Humberto';

?>