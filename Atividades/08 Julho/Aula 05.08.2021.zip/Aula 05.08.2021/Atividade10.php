<?php

$max_coluna = 10;
$max_linha = 80;

?>
<table style="width:100%;border:3px solid blue;border-collapse:collapse">
  <?php
    for ($linha = 1; $linha <= $max_linha; $linha++){
    ?>
    <tr>
    <td>Meteu</td>
  </tr>

    <tr>
        <th> Essa </th>
        <th> ? </th>
  <?php
   }
   ?>
</table>